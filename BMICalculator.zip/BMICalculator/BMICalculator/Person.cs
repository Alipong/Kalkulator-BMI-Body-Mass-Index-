﻿using System;

namespace BMICalculator
{
    public class Person
    {
        public double Weight { get; set; }
        public double Height { get; set; }

        // Method untuk menghitung BMI
        public double CalculateBMI()
        {
            if (Height <= 0) throw new ArgumentException("Tinggi badan harus lebih dari 0.");
            return Weight / (Height * Height);
        }

        // Method untuk menentukan kategori BMI
        public string GetBMICategory(double bmi)
        {
            if (bmi < 18.5)
                return "Kurus";
            else if (bmi >= 18.5 && bmi < 22.9)
                return "Normal";
            else
                return "Gemuk";
        }
    }
}