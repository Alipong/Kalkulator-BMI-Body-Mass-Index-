﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMICalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnHitung_Click(object sender, EventArgs e)
        {
            double weight, height;

            // Validasi input untuk berat badan
            if (!double.TryParse(txtWeight.Text, out weight) || weight <= 0)
            {
                MessageBox.Show("Silakan masukkan berat badan yang valid (angka positif).");
                return;
            }

            // Validasi input untuk tinggi badan
            if (!double.TryParse(txtHeight.Text, out height) || height <= 0)
            {
                MessageBox.Show("Silakan masukkan tinggi badan yang valid (angka positif).");
                return;
            }

            // Membuat objek Person
            Person person = new Person
            {
                Weight = weight,
                Height = height
            };

            // Menghitung BMI
            double bmi = person.CalculateBMI();

            // Menentukan kategori BMI
            string category = person.GetBMICategory(bmi);

            // Menampilkan hasil di label
            lblHasil.Text = $"BMI: {bmi:F2} - Kategori: {category}";
        }
    }
}
